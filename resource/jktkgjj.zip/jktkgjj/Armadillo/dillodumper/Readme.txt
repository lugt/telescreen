-------------------------------------------------
|  GROUP:      [LUNAR]                          |
|  PROGRAM:    DILLODUMPER   2.55               |
|  MADE BY:    [LUNAR_DUST]                     |
|  DATE:       June 5, 2003                     |
-------------------------------------------------

          
                                                                                        
Hello everyone, 

This is my first Dumper. THIS Dumper ONLY WORKS ON WIN2K / XP or above!

Note that this is not a full unpacker, since it won't fix everything in Arma.

This is my new tool, which I've put together over the last month, to dump armadillo
protected applications. It should support almost any version of armadillo, it especially
supports the newer versions quite well I think. 

I've tested it on Arma 2.65, 2.85, 3.0, 3.0a, 3.01, and 3.01a.

NOTE: This only really works on programs that are at least protected to some extent. 
For example, it will not work on "Standard Protection" aramadillo files, which isn't
a big deal, because for those you do not need to have any "advanced" tools to dump. I plan
on released a "lite" version to support those files soon.

This Dumper completely defeats COPYMEM II.

What does it do:

1. Runs the armadillo app, even if it's expired. (Expiration not supported currently in 3.01, 3.01a)

2. Forces the application to dump nice and clean, which is what we want, right?

3. Fixes the header of the dumped file. (OEP and VO==RO, VS==RS).

4. Allows you to rebuild IAT with ImpREC (makes IAT clean for ImpREC).


DO NOT UNPACK ON A SYSTEM WITH SOFTICE INSTALLED. Armadillo programs will detect SI and go into an
infinite loop, so unless you have your SI properly hidden, don't bother trying to unpack on a
system with it.


WHAT THIS UNPACKER DOES NOT do:


1. Does not fix Nanomites (int3 instructions). If your unpacked program comes up with a 0xc0000003 exception,
then the program has been protected with nanomites. This dumper does not fix them!

2. Cannot dump a program that will not run (Such as a program that needs username/code to run at all). However
if you have a valid username/code and enter it, it will then dump it.


This program simply dumps the file right out.

Note that it should support almost any later version of armadillo (2.XX).

I hope someone finds this somewhat useful, and I'll be seeing you!

Greetings go out to Crusader, squidge, and all you other arma experts..

- [Lunar_Dust]

MAJOR BUGS:

1. Sometimes on newer arma targets, a small executable remains running in task manager.
Not sure why just yet. 


HISTORY:

June 3, 2003: 

	a. Fixed a small bug that caused some apps to exit after dumping,
	which would not allow you to rebuild IAT with ImpREC.

	b. Added small tutorial in the package.


May 15, 2003:

	a. Support for 3.01, 3.01a Arma. Nice try guys.
	b. Removed IAT rebuild engine, too many bugs, bad plan on implementation.


April 16, 2003:

	a. Fixed some small bugs.


April 15, 2003:

	a. Finished my IAT rebuilding engine.
	b. Added code to defeat expiration check for Armadillo 3.0a.


April 5, 2003:

	a. Added code to defeat expiration checking for Armadillo 3.0.


April 4, 2003:

	a. Fixed some bugs in my ***** ****** code. Works correctly now.
	b. Fixed some timing bugs.


April 2, 2003:

	a. Added anti-IAT redirection code. Now imports wont get redirected and you
	can rebuild them in a snap with ImpREC. Still to add my own rebuilder.

	b. Added code to defeat advanced SoftICe detection. Works perfectly.

	c. Added code to defeat expiration checking. 


April 1, 2003 : Initial Release.



