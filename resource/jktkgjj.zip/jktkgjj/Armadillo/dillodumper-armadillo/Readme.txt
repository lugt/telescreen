-------------------------------------------------
|  GROUP:      [LUNAR]                          |
|  PROGRAM:    DILLODUMPER   1.6                |
|  MADE BY:    [LUNAR_DUST]                     |
|  DATE:       APRIL 1, 2003                    |
-------------------------------------------------


Hello everyone, !

This is my first unpacker.

This is my new tool, which I've put together over the last few days, to dump armadillo
protected applications. It should support almost any version of armadillo, it especially
supports the newer versions quite well I think. I've tested it on Arma 2.54 and 2.85. 
NOTE: This only really works on programs that are at least protected to some extent. 
For example, it will not work on "Standard Protection" aramadillo files, which isn't
a big deal, because for those you do not need to have any "advanced" tools to dump. 

This Dumper completely defeats COPYMEM II.

What does it do:

1. Runs the armadillo app. Runs it even if it's expired.

2. Removes "advanced SoftICE detection"

3. Proceeds to hook into the app and force it to dump, which is what we want, right?

3. Fixes the header of the dumped file. (OEP and VO==RO, VS==RS).

4. Turns off API redirection, so you can rebuild in a snap with ImpREC.


What is DOES NOT do:

1. DOes not fix the IAT table.

2. Does not fix other things, such as INT3 codes that arma is able to use now.

It simply dumps the file right out. Note that it should support almost any later version
of armadillo (2.XX). It uses a search routine to find the areas to hook :) :)

I hope someone finds this somewhat useful, and I'll be seeing you on the RCE Messageboards!

Greetings go out to Crusader, squidge, and all you other arma experts..

-nikolatesla20 [Lunar_Dust]

BUGS:

1. Sometimes on newer arma targets, a small executable remains running in task manager.
Not sure why just yet. 


HISTORY:



April 2, 2003:

	a. Added anti-IAT redirection code. Now imports wont get redirected and you
	can rebuild them in a snap with ImpREC. Still to add my own rebuilder.

	b. Added code to defeat advanced SoftICe detection. WOrks perfectly.

	c. Added code to defeat expiration checking. 


April 1, 2003 : Initial Release.



