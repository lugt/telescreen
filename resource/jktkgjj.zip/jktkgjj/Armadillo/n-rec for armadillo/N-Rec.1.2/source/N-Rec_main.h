//---------------------------------------------------------------------------

#ifndef NRec_mainH
#define NRec_mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <Mask.hpp>

#include <stack.h>
#include <deque.h>
#include <vector.h>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
#define  MODE_DISASM   1
#define  MODE_DEBUG    2
//---------------------------------------------------------------------------
typedef unsigned short word;
typedef unsigned int dword;
//---------------------------------------------------------------------------
struct section
{
  unsigned char *data;
  dword base;
  dword size;
  dword phys;
};
//---------------------------------------------------------------------------
struct codeBlock
{
  dword begin;
  dword end;
};
//---------------------------------------------------------------------------
class TDisasm : public TThread
{
public:
        void __fastcall Execute(void);
        __fastcall TDisasm(bool CreateSuspended);
        __fastcall ~TDisasm(void );
private:
        bool __fastcall searchMarked(dword addr);
        void __fastcall disasmThread(dword addr, bool isBlock=false, dword endAddr=0);
        deque<dword,allocator<dword> > marks;
        void __fastcall AddInfo( AnsiString string );
        void __fastcall AddErr( AnsiString string );
        HANDLE hSem;
};
//---------------------------------------------------------------------------
struct thread
{
  dword id;
  HANDLE hnd;
};
//---------------------------------------------------------------------------
class TMain : public TForm
{
__published:	// IDE-managed Components
        TEdit *SrcName;
        TLabel *Label1;
        TButton *OpenSrc;
        TButton *Process;
        TListBox *info;
        TOpenDialog *OpenDialog;
        TLabel *Label2;
        TEdit *EPName;
        TButton *OpenEP;
        TCheckBox *isWarn;
        TRadioGroup *Mode;
        TButton *Cancel;
        TListBox *err;
        TLabel *Label3;
        void __fastcall OpenSrcClick(TObject *Sender);
        void __fastcall ProcessClick(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall OpenEPClick(TObject *Sender);
        void __fastcall CancelClick(TObject *Sender);
private:	// User declarations
        unsigned char *sourceFile;
        section *sections;
        dword __fastcall fillSections(unsigned char *sourceFile);
        dword imageBase;
        void __fastcall cleanupSections( void );
        void __fastcall SetButtons( bool state );
        TDisasm *disasm;
        HANDLE dbgProcess;
public:		// User declarations
        dword nanoCount;
        dword *nano_ccad, *nano_jdst;
        byte *nano_jtyp, *nano_jsiz;
        int sectionsCount;
        unsigned char * __fastcall mapVirtualToPhys(dword addr);
        dword __fastcall restSectionLen(dword addr);
        dword __fastcall mapPhysToVirtual(unsigned char *phys_addr);
        dword __fastcall mapVirtualToFileOffset(dword addr);
        stack<dword,vector<dword> > stack;
        __fastcall TMain(TComponent* Owner);
        TStringList *diffs;
        bool __fastcall processNanomite(dword addr, unsigned char *phys_addr, int mode);
        void __fastcall AddThread(dword id, HANDLE hnd);
        void __fastcall DelThread(dword id);
        HANDLE __fastcall GetThread(dword id);
        deque<thread,allocator<thread> > threads;
        deque<codeBlock,allocator<codeBlock> > blocks;
};
//---------------------------------------------------------------------------
extern PACKAGE TMain *Main;
//---------------------------------------------------------------------------
#endif
