//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "inject_form.h"

#include "params.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender)
{
    DWORD rr;
    unsigned char buf[0x1000];
    DWORD pages=cPages->Text.ToInt();
    DWORD start=cStart->Text.ToInt();
    AnsiString file=ExtractFilePath(ParamStr(0))+cDump->Text;
    AnsiString mess=AnsiString("Ready to dump ")+AnsiString(pages)+AnsiString(" pages into ")+file;
    MessageBox(NULL,mess.c_str(),"Inject",MB_OK | MB_TOPMOST);
    HANDLE h=CreateFile(file.c_str(),GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,0);
    for( int i=0; i<pages; i++ ) //xx - ����� ������� ������� ����� �������
    {
      ZeroMemory(buf,0x1000);
      CopyMemory(buf,(const void *)(start+i*0x1000),0x1000);
      WriteFile(h,buf,sizeof(buf),&rr,NULL);
    }
    CloseHandle(h);
    MessageBox(NULL,"Done","Inject",MB_OK | MB_TOPMOST);
}
//---------------------------------------------------------------------------

