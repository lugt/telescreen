#ifndef __PARAMS__
#define __PARAMS__

#define PAGES_FILE "pages.dat"

#endif
