Anti-UPX-SCRAMBLER v1.0 by DraCooLa
------------------------------------


I. What is Anti-UPX-SCRAMBLER?
-------------------------------

Anti-UPX-SCRAMBLER is a program, which decrypts any
PE executable files encrypted by UPX-SCRAMBLER.


II. Usage
----------

Run Anti-UPX-SCRAMBLER and select encrypted file.
Anti-UPX-SCRAMBLER will overwrite encrypted
file so the name of ecrypted file will be the same.


III. Tested with
-----------------

- UPX-Scrambler 3.04
- UPX-Scrambler 3.06
- UPX-Scrambler RC 1
- UPX-Scrambler RC 1.03
- UPX-Scrambler RC 1.05


IV. Disclaimer
---------------

I'm NOT responsible for any damage caused by using this
utility... or what users do with it!


V. Greetings
-------------

Everyone :)


VI. Contact
------------

Any suggestions, bug reports, comments... feel free
to drop me a mail @ dracoola@gmx.de

Best regards,
DraCooLa
